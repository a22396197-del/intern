# Free Intern — Student Internship Discovery & Career Readiness Platform

**Discover Internships. Build Skills. Start Your Career.**

Free Intern is a full-stack React 19 + TypeScript + Express + D3.js + Google Gemini AI platform that helps students discover verified private, government, and PM Internship Scheme opportunities, check deterministic eligibility, scan resumes ethically, practice 15-question role-specific mock interviews with D3.js progress visualization, and earn verified skill badges.

## Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment (optional):**
   ```bash
   cp .env.example .env
   ```
   *(You can optionally set `GEMINI_API_KEY` in `.env`. The platform includes a deterministic fallback engine so all features work out-of-the-box even without an API key.)*

3. **Run the development server:**
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) (or [http://localhost:3000/?autostart=1](http://localhost:3000/?autostart=1) for automatic demo student login).

4. **Run unit tests:**
   ```bash
   npx tsx --test src/utils/logic.test.ts
   ```

## Demo Accounts
- **Student:** `student@freeintern.edu` / `Student@123`
- **Admin:** `admin@freeintern.edu` / `Admin@123`

See **[PROJECT_DOCUMENTATION.md](./PROJECT_DOCUMENTATION.md)** for the complete 16-module functional specification, system architecture, and algorithm documentation.
